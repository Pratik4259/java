let s1 = "pratik";
let s2 = "vekariya";
let s3 = s1 + " " + s2;
document.write(s3);